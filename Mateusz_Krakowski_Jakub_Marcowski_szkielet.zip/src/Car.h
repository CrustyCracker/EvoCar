/*
Author:         Jakub Marcowski
Description:    Creates a car with a polygon (car's body)
    and two circles (front and back wheels).
*/

#ifndef CAR_H
#define CAR_H
#include "box2d/box2d.h"
#include "Shape.h"
#include "../config/Config.h"
/*
Author:         Jakub Marcowski, Mateusz Krakowski
Description:    Header file for Car class.
*/
class Car {
   private:
    b2World* world;
    Polygon body;
    Circle frontWheel;
    Circle backWheel;
    sf::Color bodyColor;

   public:
    Car(b2World* world, float x, float y, std::vector<b2Vec2> vertices, float density,
        float friction, float wheelRadious, sf::Color bodyColor, sf::Color wheelColor);

    Polygon* getBody();
    Circle* getFrontWheel();
    Circle* getBackWheel();
    sf::Color* getBodyColor();
};

#endif
