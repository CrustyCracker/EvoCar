#!/bin/bash
sudo apt-get update
sudo apt-get install libbox2d-dev libgtest-dev cmake build-essential libimgui-dev libsfml-dev libudev-dev libfreetype-dev libxrandr-dev libx11-dev -y
sudo apt-get upgrade -y