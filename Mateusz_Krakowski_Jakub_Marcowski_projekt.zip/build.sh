cd build
cmake ..
make